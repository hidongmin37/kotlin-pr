package com.group.libraryapp.dto.book.request;

public class BookRequest {

  private String name;

  public String getName() {
    return name;
  }

}
